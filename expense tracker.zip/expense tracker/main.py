from datetime import date as date_type
from typing import Optional, List

from fastapi import FastAPI, HTTPException, Query, Depends
from pydantic import BaseModel, Field
from sqlalchemy import create_engine, Column, Integer, Float, String, Date, func
from sqlalchemy.orm import sessionmaker, declarative_base, Session

#  Database setup -
DATABASE_URL = "sqlite:///./expenses.db"
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


#  Database table model
class ExpenseDB(Base):
    __tablename__ = "expenses"

    id = Column(Integer, primary_key=True, index=True)
    amount = Column(Float, nullable=False)
    category = Column(String, nullable=False, index=True)
    description = Column(String, nullable=True)
    date = Column(Date, nullable=False, default=date_type.today)


Base.metadata.create_all(bind=engine)


#  Request/response schemas
class ExpenseCreate(BaseModel):
    amount: float = Field(..., gt=0, description="Must be greater than 0")
    category: str = Field(..., min_length=1)
    description: Optional[str] = None
    date: Optional[date_type] = None


class ExpenseUpdate(BaseModel):
    amount: Optional[float] = Field(None, gt=0)
    category: Optional[str] = Field(None, min_length=1)
    description: Optional[str] = None
    date: Optional[date_type] = None


class ExpenseOut(BaseModel):
    id: int
    amount: float
    category: str
    description: Optional[str] = None
    date: date_type

    class Config:
        from_attributes = True


#  App
app = FastAPI(title="Expense Tracker API")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@app.get("/")
def read_root():
    return {"message": "Welcome to the Expense Tracker API"}


# CREATE
@app.post("/expenses", response_model=ExpenseOut, status_code=201)
def create_expense(expense: ExpenseCreate, db: Session = Depends(get_db)):
    db_expense = ExpenseDB(
        amount=expense.amount,
        category=expense.category,
        description=expense.description,
        date=expense.date or date_type.today(),
    )
    db.add(db_expense)
    db.commit()
    db.refresh(db_expense)
    return db_expense


# LIST + FILTER
@app.get("/expenses", response_model=List[ExpenseOut])
def list_expenses(
    category: Optional[str] = None,
    start_date: Optional[date_type] = None,
    end_date: Optional[date_type] = None,
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: Session = Depends(get_db),
):
    query = db.query(ExpenseDB)

    if category:
        query = query.filter(ExpenseDB.category == category)
    if start_date:
        query = query.filter(ExpenseDB.date >= start_date)
    if end_date:
        query = query.filter(ExpenseDB.date <= end_date)

    return query.offset(offset).limit(limit).all()


# SUMMARY (must be defined before /expenses/{expense_id})
@app.get("/expenses/summary")
def summary(
    start_date: Optional[date_type] = None,
    end_date: Optional[date_type] = None,
    group_by: str = "category",
    db: Session = Depends(get_db),
):
    if group_by not in ("category", "month"):
        raise HTTPException(
            status_code=400, detail="group_by must be 'category' or 'month'")

    query = db.query(ExpenseDB)

    if start_date:
        query = query.filter(ExpenseDB.date >= start_date)
    if end_date:
        query = query.filter(ExpenseDB.date <= end_date)

    if group_by == "category":
        results = (
            query.with_entities(ExpenseDB.category, func.sum(ExpenseDB.amount))
            .group_by(ExpenseDB.category)
            .all()
        )
        return [{"category": r[0], "total": round(r[1], 2)} for r in results]

    results = (
        query.with_entities(
            func.strftime("%Y-%m", ExpenseDB.date), func.sum(ExpenseDB.amount)
        )
        .group_by(func.strftime("%Y-%m", ExpenseDB.date))
        .all()
    )
    return [{"month": r[0], "total": round(r[1], 2)} for r in results]


# READ ONE
@app.get("/expenses/{expense_id}", response_model=ExpenseOut)
def get_expense(expense_id: int, db: Session = Depends(get_db)):
    expense = db.query(ExpenseDB).filter(ExpenseDB.id == expense_id).first()
    if not expense:
        raise HTTPException(status_code=404, detail="Expense not found")
    return expense


# UPDATE
@app.put("/expenses/{expense_id}", response_model=ExpenseOut)
def update_expense(expense_id: int, expense: ExpenseUpdate, db: Session = Depends(get_db)):
    db_expense = db.query(ExpenseDB).filter(ExpenseDB.id == expense_id).first()
    if not db_expense:
        raise HTTPException(status_code=404, detail="Expense not found")

    update_data = expense.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_expense, key, value)

    db.commit()
    db.refresh(db_expense)
    return db_expense


# DELETE
@app.delete("/expenses/{expense_id}", status_code=204)
def delete_expense(expense_id: int, db: Session = Depends(get_db)):
    db_expense = db.query(ExpenseDB).filter(ExpenseDB.id == expense_id).first()
    if not db_expense:
        raise HTTPException(status_code=404, detail="Expense not found")

    db.delete(db_expense)
    db.commit()
    return None
